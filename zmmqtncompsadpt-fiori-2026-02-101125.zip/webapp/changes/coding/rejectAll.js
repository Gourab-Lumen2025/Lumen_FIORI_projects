sap.ui.define(
    [
        'sap/ui/core/mvc/ControllerExtension',
        'sap/ui/model/json/JSONModel',
        'sap/m/MessageBox',
        'sap/m/MessageToast',
        'sap/ui/model/Filter',
        'sap/ui/model/FilterOperator',
        'sap/ui/core/mvc/OverrideExecution'
    ],
    function (
        ControllerExtension, JSONModel, MessageBox, MessageToast, Filter, FilterOperator, OverrideExecution
    ) {
        'use strict';
        return ControllerExtension.extend("customer.lumen.zmmqtncompsadpt.rejectAll", {
            // metadata: {
            // 	// extension can declare the public methods
            // 	// in general methods that start with "_" are private
            // 	methods: {
            // 		publicMethod: {
            // 			public: true /*default*/ ,
            // 			final: false /*default*/ ,
            // 			overrideExecution: OverrideExecution.Instead /*default*/
            // 		},
            // 		finalPublicMethod: {
            // 			final: true
            // 		},
            // 		onMyHook: {
            // 			public: true /*default*/ ,
            // 			final: false /*default*/ ,
            // 			overrideExecution: OverrideExecution.After
            // 		},
            // 		couldBePrivate: {
            // 			public: false
            // 		}
            // 	}
            // },
            // // adding a private method, only accessible from this controller extension
            _privateMethod: function () {

            },
            // // adding a public method, might be called from or overridden by other controller extensions as well
            // publicMethod: function() {},
            // // adding final public method, might be called from, but not overridden by other controller extensions as well
            // finalPublicMethod: function() {},
            // // adding a hook method, might be called by or overridden from other controller extensions
            // // override these method does not replace the implementation, but executes after the original method
            // onMyHook: function() {},
            // // method public per default, but made private via metadata
            // couldBePrivate: function() {},
            // // this section allows to extend lifecycle hooks or override public methods of the base controller
            // override: {
            // 	/**
            // 	 * Called when a controller is instantiated and its View controls (if available) are already created.
            // 	 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
            // 	 * @memberOf {{controllerExtPath}}
            // 	 */
            // 	onInit: function() {
            // 	},
            // 	/**
            // 	 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
            // 	 * (NOT before the first rendering! onInit() is used for that one!).
            // 	 * @memberOf {{controllerExtPath}}
            // 	 */
            // 	onBeforeRendering: function() {
            // 	},
            // 	/**
            // 	 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
            // 	 * This hook is the same one that SAPUI5 controls get after being rendered.
            // 	 * @memberOf {{controllerExtPath}}
            // 	 */
            // 	onAfterRendering: function() {
            // 	},
            // 	/**
            // 	 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
            // 	 * @memberOf {{controllerExtPath}}
            // 	 */
            // 	onExit: function() {
            // 	},
            // 	// override public method of the base controller
            // 	basePublicMethod: function() {
            // 	}
            // }
            override: {
                /**
                 * Called when a controller is instantiated and its View controls (if available) are already created.
                 * Creating OData model and JSON Model. setting JSON model to view with named Model.
                 * @memberOf {{controllerExtPath}}
                */
                onAfterRendering: function () {
                    this._oRejectAllModel = new sap.ui.model.odata.ODataModel('/sap/opu/odata/sap/ZPTP_COMPARE_QUOTE_REJECT_SRV/', true);
                    sap.ui.getCore().setModel(new sap.ui.model.json.JSONModel({ 'RFQValue': '', 'RFQType': '' }, 'rfqModel'));
                },
            },
            /**
             * Event handler for Maintain Reason code in Manage RFQ after Award/Reject Quotations Link press event in List page.
             * Navigating to Request Quotation app with RFQ Number when the link is pressed.
             * @param {sap.ui.base.Event} oEvent - The event object
            */
            fnManageRFQ: function () {
                var rfqValue = this.base.getView().byId('application-RequestForQuotation-zcompare-component---s2p.mm.pur.qtn.compares1.OverviewPage--s2p.mm.pur.qtn.compares1.fragment.rfqSearch.SearchField').getValue();
                if (rfqValue != '') {
                    var O = `C_RequestForQuotationEnhWD(RequestForQuotation='${rfqValue}',DraftUUID=guid'00000000-0000-0000-0000-000000000000',IsActiveEntity=true)`;
                    var oCrossAppNav = sap.ushell.Container.getService("CrossApplicationNavigation");
                    oCrossAppNav.toExternal({
                        target: {
                            shellHash: "RequestForQuotation-zmanage&/" + encodeURIComponent(O)
                        }
                    });
                } else {
                    sap.m.MessageBox.show('Kindly Select RFQ Number');
                }
                // if (rfqValue != '') {
                //     //URL Should be Dynamic
                //     var url = `https://ns2wd1app1.saperp.corp.intranet:44301/sap/bc/ui2/flp?&sap-language=EN#RequestForQuotation-zmanage&/C_RequestForQuotationEnhWD(RequestForQuotation='${rfqValue}',DraftUUID=guid'00000000-0000-0000-0000-000000000000',IsActiveEntity=true)/?sap-iapp-state--history=TASC62UQ9EU4BYBESF96WH5RGTRC8AP1K2MKS82K4&sap-iapp-state-C_RequestForQuotationEnhWD=ASVZ7V7BJR8FD5USYIN3BAR6VR2AN75DRPRUBMWQ`;
                //     window.location.href = url;
                // } else {
                //     sap.m.MessageBox.show('Kindly Select RFQ Number');
                // }
            },
            /**
             * Event handler for Reject All button press event in List page.
             * Making create call with RFQ Number when RFQType is ZFPB and refreshing table model when the Reject All button is pressed.
             * @param {sap.ui.base.Event} oEvent - The event object
            */
            fnRejectAll: function () {
                var rfqValue = this.base.getView().byId('application-RequestForQuotation-zcompare-component---s2p.mm.pur.qtn.compares1.OverviewPage--s2p.mm.pur.qtn.compares1.fragment.rfqSearch.SearchField').getValue();
                this.base.getView().getModel().read(`/C_RFQValueHelp('${rfqValue}')`, {
                    success: function (oData) {
                        if (oData.RFQType == 'ZFPB') {
                            MessageBox.information('Please maintain a rejection reason code in RFQ if you decide to Reject Bids , otherwise Purchase requisition update on rejection will not happen.', {
                                actions: [MessageBox.Action.YES, MessageBox.Action.NO],
                                onClose: function (sAction) {
                                    if (sAction == 'YES') {
                                        var payload = {
                                            "EBELN": rfqValue,
                                            "MESSAGE": '',
                                            "TYPE": ''
                                        }
                                        this._oRejectAllModel.create(`/RFQ_InputSet`, payload, {
                                            success: function (oData, oResponse) {
                                                if (oData.TYPE == 'S') {
                                                    MessageBox.success(oData.MESSAGE);
                                                } else {
                                                    MessageBox.error(oData.MESSAGE);
                                                }
                                                this.base.getView().byId('application-RequestForQuotation-zcompare-component---s2p.mm.pur.qtn.compares1.OverviewPage--supplierQuotationTableFragment--s2p.mm.pur.qtn.compares1.fragment.QuotationTable.InnerTable').getModel().refresh(true);
                                                this.base.getView().byId('application-RequestForQuotation-zcompare-component---s2p.mm.pur.qtn.compares1.OverviewPage--supplierQuotationTableFragment--s2p.mm.pur.qtn.compares1.fragment.QuotationTable.InnerTable').getModel().updateBindings();
                                            }.bind(this),
                                            error: function (oError) {
                                                console.error(oError);
                                            }.bind(this)
                                        });
                                    }
                                }.bind(this)
                            }
                            );
                        } else {
                            MessageBox.warning(`This action is not allowed for ${RFQType} document type`);
                        }
                    }.bind(this),
                    error: function (oError) {
                        MessageBox.error('Records are not posted due to an error.');
                    }.bind(this)
                });


            }
        });
    }
);
