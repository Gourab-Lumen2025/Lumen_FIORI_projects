/* global QUnit */

sap.ui.require(["lumen/zotcsparedashboard/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
