sap.ui.define([
	"lumen/zotcsparedashboard/test/unit/controller/Main.controller"
], function () {
	"use strict";
});
