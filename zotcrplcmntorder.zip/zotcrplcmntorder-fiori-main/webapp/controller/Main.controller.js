sap.ui.define([
  "sap/ui/core/mvc/Controller",
  "sap/ui/core/Fragment",
  "sap/m/MessageBox"
],
  function (Controller, Fragment, MessageBox) {
    "use strict";
    var that = this;
    var view, data;
    var oDataModel;
    var oTab1Model, oTab2Model, oTab3Model, oTab4Model, oTab5Model, oTab6Model, oTab7Model, oTab8Model, oTab9Model, oTab10Model, oActivityTabModel;
    var oResourceModel;
    //Array Filter

    return Controller.extend("lumen.zotcsparedashboard.controller.Main", {
      onInit: function () {

        view = this.getView();
        oTab1Model = this.getOwnerComponent().getModel("oTab1Model");
        oTab2Model = this.getOwnerComponent().getModel("oTab2Model");
        oTab3Model = this.getOwnerComponent().getModel("oTab3Model");
        oTab4Model = this.getOwnerComponent().getModel("oTab4Model");
        oTab5Model = this.getOwnerComponent().getModel("oTab5Model");
        oTab6Model = this.getOwnerComponent().getModel("oTab6Model");
        oTab7Model = this.getOwnerComponent().getModel("oTab7Model");
        oTab8Model = this.getOwnerComponent().getModel("oTab8Model");
        oTab9Model = this.getOwnerComponent().getModel("oTab9Model");
        oTab10Model = this.getOwnerComponent().getModel("oTab10Model");
        oActivityTabModel = this.getOwnerComponent().getModel("oActivityTabModel");
        oResourceModel = this.getOwnerComponent().getModel("i18n"); //Getting Resource Model defined in Manifest.

      },




      onAfterRendering: function () {
        sap.ui.core.BusyIndicator.show();
        data = false;
        var startupParams =
          this.getOwnerComponent().getComponentData().startupParameters;
        if (Object.keys(startupParams).length !== 0) {
          if (startupParams.ReplacementOrder[0]) {
            this.salesdocument = startupParams.ReplacementOrder[0];
          }
        }
        // Filter for Salesdocument
        var filters = [];
        var oFilter_salesdoc = new sap.ui.model.Filter(
          "Salesdocument",
          sap.ui.model.FilterOperator.EQ, this.salesdocument
        );
        filters.push(oFilter_salesdoc);

        oDataModel = this.getOwnerComponent().getModel();

        oDataModel.read("/ZOTC_SPARES_DASHBOARD_PROJ", { //Calling ZOTC_SPARES_DASHBOARD_PROJ entity set with expand URL paramters
          filters: [filters],
          urlParameters: {
            "$expand": "to_Tab1,to_Tab2,to_Tab3,to_Tab4,to_Tab5,to_Tab6,to_Tab7,to_Tab8,to_Tab9,to_Tab10,to_ActivityTab"
          },
          success: function (oData, oResponse) { // On Success call back function, setting the model data
            if (oData.results.length > 0) {
              data = true;
              oTab1Model.setData(oResponse.data.results[0].to_Tab1);
              oTab2Model.setData(oResponse.data.results[0].to_Tab2);
              oTab3Model.setData(oResponse.data.results[0].to_Tab3);
              oTab4Model.setData(oResponse.data.results[0].to_Tab4);
              oTab5Model.setData(oResponse.data.results[0].to_Tab5);
              oTab6Model.setData(oResponse.data.results[0].to_Tab6);
              oTab7Model.setData(oResponse.data.results[0].to_Tab7);
              oTab8Model.setData(oResponse.data.results[0].to_Tab8);
              oTab9Model.setData(oResponse.data.results[0].to_Tab9);
              oTab10Model.setData(oResponse.data.results[0].to_Tab10);
              oActivityTabModel.setData(oResponse.data.results[0].to_ActivityTab)
              view.byId("idTable1").setModel(oTab1Model, "Tab1Model");
              view.byId("idTable2").setModel(oTab2Model, "Tab2Model");
              view.byId("idTable3").setModel(oTab3Model, "Tab3Model");
              view.byId("idTable4").setModel(oTab4Model, "Tab4Model");
              view.byId("idTable5").setModel(oTab5Model, "Tab5Model");
              view.byId("idTable6").setModel(oTab6Model, "Tab6Model");
              view.byId("idTable7").setModel(oTab7Model, "Tab7Model");
              view.byId("idTable8").setModel(oTab8Model, "Tab8Model");
              view.byId("idTable9").setModel(oTab9Model, "Tab9Model");
              view.byId("idTable10").setModel(oTab10Model, "Tab10Model");
              view.byId("idIActivityLogTable").setModel(oActivityTabModel, "ActivityTabModel");
            }
            sap.ui.core.BusyIndicator.hide();
          },
          error: function (oError) {
            sap.ui.core.BusyIndicator.hide();
            var response = JSON.parse(oError.responseText); //In case of error, display the message coming from backend.
            MessageBox.error(
              response.error.message.value
            );
          }
        });
      },
      onPressCreateLog: function () {
        if (data) {
          var oView = this.getView();
          if (!this._oFragmentcreate) {
            Fragment.load({
              id: view.getId(),
              name: "lumen.zotcsparedashboard.fragment.AddLog",
              controller: this,
            }).then(
              function (oFragmentcreate) {
                this._oFragmentcreate = oFragmentcreate;
                oView.addDependent(this._oFragmentcreate);
                this._oFragmentcreate.open();
              }.bind(this)
            );
          } else {
            this._oFragmentcreate.open();
          }
        }
        else {
          MessageBox.error(oResourceModel.getResourceBundle().getText("Salesdocmissing"));

        }
      },
      onPressCancel: function () {
        this._oFragmentcreate.close();
      },
      onPressSave: function () {

        sap.ui.core.BusyIndicator.show();
        var oTable = this.byId("idIActivityLogTable");
        var sAddLogText = this.byId("idAddLogText").getValue();
        let payload = {
          SalesDocument: this.salesdocument,
          SalesDocItem: '000010',
          ActNote: sAddLogText
        }
        var filters = [];
        var oFilter_salesdoc = new sap.ui.model.Filter(
          "Salesdocument",
          sap.ui.model.FilterOperator.EQ, this.salesdocument
        );
        filters.push(oFilter_salesdoc);
        this.getOwnerComponent().getModel("ZOTC_UTILITY_SERVICE_SRV").create("/ActivityLogSet", payload, {
          success: function (oData, oResponse) {
            oDataModel.read("/ZOTC_SPARES_DASHBOARD_PROJ", { //Calling ZOTC_SPARES_DASHBOARD_PROJ entity set with expand URL paramters
              filters: [filters],
              urlParameters: {
                "$expand": "to_ActivityTab"
              },
              success: function (oData, oResponse) { // On Success call back function, setting the model data
                oActivityTabModel.setData(oResponse.data.results[0].to_ActivityTab);
                oTable.removeSelections(true);
                view.byId("idEditLogButton").setEnabled(false);
                view.byId("idDeleteLogButton").setEnabled(false);

                sap.ui.core.BusyIndicator.hide();
              },
              error: function (oError) {
                sap.ui.core.BusyIndicator.hide();
                var response = JSON.parse(oError.responseText); //In case of error, display the message coming from backend.
                //  that._errorMessage(response.error.message.value);
                MessageBox.error(
                  response.error.message.value
                );
              }
            });
            MessageBox.success(oResourceModel.getResourceBundle().getText("Created"), {
              title: "Success",
              icon: MessageBox.Icon.SUCCESS,
              actions: [oResourceModel.getResourceBundle().getText("Ok")]
            });
          },
          error: function (oError) { //Error Callback function
            sap.ui.core.BusyIndicator.hide();
            var response = JSON.parse(oError.responseText);
            var vMsg = response.error.message.value; //capture 404 error
            MessageBox.show(vMsg);
          }
        });

        this._oFragmentcreate.close();
      },

      onPressEditLog: function (oEvent) {
        var oView = this.getView();
        var oTable = this.byId("idIActivityLogTable");
        var oSelectedItem = oTable.getSelectedItem();
        var oContext = oSelectedItem.getBindingContext("ActivityTabModel");
        if (!this._oFragmentEdit) {
          Fragment.load({
            id: oView.getId(),
            name: "lumen.zotcsparedashboard.fragment.EditLog",
            controller: this,
          }).then(
            function (oFragmentEdit) {
              this._oFragmentEdit = oFragmentEdit;
              oView.addDependent(this._oFragmentEdit);
              oView.byId("idEditLogTextArea").setValue(oContext.getObject().ActNotes);
              this._oFragmentEdit.open();
            }.bind(this)
          );
        } else {
          oView.byId("idEditLogTextArea").setValue(oContext.getObject().ActNotes);
          this._oFragmentEdit.open();
        }

      },
      onPressSaveEditLog: function () {
        var oView = this.getView();
        var oTable = this.byId("idIActivityLogTable");
        var oSelectedItem = oTable.getSelectedItem();
        var oContext = oSelectedItem.getBindingContext("ActivityTabModel");
        let payload = {
          ActNote: this.getView().byId("idEditLogTextArea").getValue(),
        }
        // Filter for Salesdocument
        var filters = [];
        var oFilter_salesdoc = new sap.ui.model.Filter(
          "Salesdocument",
          sap.ui.model.FilterOperator.EQ, this.salesdocument
        );
        filters.push(oFilter_salesdoc);

        var path = "/ActivityLogSet(SalesDocument='" + this.salesdocument + "',SalesDocItem='" + '000010' + "',CreatedOn='" + oContext.getObject().CreatedDate + "',CreatedTme='" + encodeURIComponent(oContext.getObject().Createdtime) + "')";
        this.getOwnerComponent().getModel("ZOTC_UTILITY_SERVICE_SRV").update(path, payload, {
          success: function (oData, oResponse) {

            sap.ui.core.BusyIndicator.hide();
            oDataModel.read("/ZOTC_SPARES_DASHBOARD_PROJ", { //Calling ZOTC_SPARES_DASHBOARD_PROJ entity set with expand URL paramters
              filters: [filters],
              urlParameters: {
                "$expand": "to_ActivityTab"
              },
              success: function (oData, oResponse) { // On Success call back function, setting the model data
                oActivityTabModel.setData(oResponse.data.results[0].to_ActivityTab);
                oTable.removeSelections(true);
                view.byId("idEditLogButton").setEnabled(false);
                view.byId("idDeleteLogButton").setEnabled(fakse);
                sap.ui.core.BusyIndicator.hide();
              },
              error: function (oError) {
                sap.ui.core.BusyIndicator.hide();
                var response = JSON.parse(oError.responseText); //In case of error, display the message coming from backend.

                MessageBox.error(
                  response.error.message.value
                );
              }
            });
            MessageBox.success(oResourceModel.getResourceBundle().getText("Updated"), {
              title: "Success",
              icon: MessageBox.Icon.SUCCESS,
              actions: [oResourceModel.getResourceBundle().getText("Ok")]
            });
          },
          error: function (oError) { //Error Callback function
            sap.ui.core.BusyIndicator.hide();
            var response = JSON.parse(oError.responseText);
            var vMsg = response.error.message.value; //capture 404 error
            MessageBox.show(vMsg);
          }
        });

        this._oFragmentEdit.close();

      },
      onPressCancelEditLog: function () {
        this._oFragmentEdit.close();
      },

      onPressDeleteLog: function () {
        var oView = this.getView();
        var oTable = this.byId("idIActivityLogTable");
        var oSelectedItem = oTable.getSelectedItem();
        var oContext = oSelectedItem.getBindingContext("ActivityTabModel");
        // Filter for Salesdocument
        var filters = [];
        var oFilter_salesdoc = new sap.ui.model.Filter(
          "Salesdocument",
          sap.ui.model.FilterOperator.EQ, this.salesdocument
        );
        filters.push(oFilter_salesdoc);

        var path = "/ActivityLogSet(SalesDocument='" + this.salesdocument + "',SalesDocItem='" + '000010' + "',CreatedOn='" + oContext.getObject().CreatedDate + "',CreatedTme='" + encodeURIComponent(oContext.getObject().Createdtime) + "')";
        this.getOwnerComponent().getModel("ZOTC_UTILITY_SERVICE_SRV").remove(path, {
          success: function (oData, oResponse) {

            sap.ui.core.BusyIndicator.hide();
            oDataModel.read("/ZOTC_SPARES_DASHBOARD_PROJ", { //Calling ZOTC_SPARES_DASHBOARD_PROJ entity set with expand URL paramters
              filters: [filters],
              urlParameters: {
                "$expand": "to_ActivityTab"
              },
              success: function (oData, oResponse) { // On Success call back function, setting the model data
                oActivityTabModel.setData(oResponse.data.results[0].to_ActivityTab);
                oTable.removeSelections(true);
                view.byId("idEditLogButton").setEnabled(false);
                view.byId("idDeleteLogButton").setEnabled(false);
                sap.ui.core.BusyIndicator.hide();
              },
              error: function (oError) {
                sap.ui.core.BusyIndicator.hide();
                var response = JSON.parse(oError.responseText); //In case of error, display the message coming from backend.

                MessageBox.error(
                  response.error.message.value
                );
              }
            });
            MessageBox.success(oResourceModel.getResourceBundle().getText("Deleted"), {
              title: "Success",
              icon: MessageBox.Icon.SUCCESS,
              actions: [oResourceModel.getResourceBundle().getText("Ok")]
            });
          },
          error: function (oError) { //Error Callback function
            sap.ui.core.BusyIndicator.hide();
            var response = JSON.parse(oError.responseText);
            var vMsg = response.error.message.value; //capture 404 error
            MessageBox.show(vMsg);
          }
        });

        this._oFragmentEdit.close();
      },
      onSelectionChange: function () {
        view.byId("idEditLogButton").setEnabled(true);
        view.byId("idDeleteLogButton").setEnabled(true);

      },

      //On Cick of the Request / Replacement Order Number, navigate to Manage Sales Order Version 2 Fiori App
      handleReplacementOrderPress: function (oEvent) {
        var order = oEvent.getSource().getParent().getBindingContext("Tab1Model").getObject().Request;
        var oCrossAppNav = sap.ushell.Container.getService("CrossApplicationNavigation");

        //Navigate to Manage Sales Order Version 2 App (Standard)
        oCrossAppNav.toExternal({
          target: { semanticObject: "SalesOrder", action: "manageV2" },
          params: { SalesOrder: order }
        })

      },
      // On Click of Case Number, open a new Tab with MTA URL
      handleCaseNumPress: function (oEvent) {
        var casenum = oEvent.getSource().getParent().getBindingContext("Tab1Model").getObject().CaseNum;
        // Create a new URL object
        const url = new URL('https://mta.centurylink.com/');
        // Access the URLSearchParams object
        const params = url.searchParams;

        // Add parameters using append()
        params.append('ticketId', casenum);
        window.open(url, "_blank");
      },
      // On Click of SubCase Number, open a new Tab with MTA URL
      handleSubCasePress: function (oEvent) {
        var subcasenum = oEvent.getSource().getParent().getBindingContext("Tab1Model").getObject().SubCase;
        // Create a new URL object
        const url = new URL('https://mta.centurylink.com/');
        // Access the URLSearchParams object
        const params = url.searchParams;
        params.append('ticketId', subcasenum);
        window.open(url, "_blank");
      },

      handleOrderPress: function (oEvent) { //On click of Order Number, navigate to respective Fiori Apps
        var order = oEvent.getSource().getParent().getBindingContext("Tab7Model").getObject().PO;
        var ordertype = oEvent.getSource().getParent().getBindingContext("Tab7Model").getObject().OrderType;
        var oCrossAppNav = sap.ushell.Container.getService("CrossApplicationNavigation");

        if (ordertype == 'RP') { //Navigate to Manage Sales Order Version 2 App (Standard) in case of Repair Order
          oCrossAppNav.toExternal({
            target: { semanticObject: "SalesOrder", action: "manageV2" },
            params: { SalesOrder: order }
          })
        }
        else if (ordertype == 'RT') { // Navigate to Display Customer Returns GUI app (VA03) for Return Order
          oCrossAppNav.toExternal({
            target: { semanticObject: "CustomerReturn", action: "display" },
            params: { CustomerReturn: order }
          })
        }
        else {
          oCrossAppNav.toExternal({ //Navigate to Manage Purchase Orders Fiori App for Repair and Vendor Return Order
            target: { semanticObject: "PurchaseOrder", action: "display" },
            params: { PurchaseOrder: order }
          })
        }

      },

      //On click of Carrier Press, navigate to Fiori app (This is only for Replacement Order Type)
      handleCarrierPress: function (oEvent) { //Navigate to Manage Outbound Delivery Factsheet App (Standard)
        var deliverydoc = oEvent.getSource().getParent().getBindingContext("Tab7Model").getObject().DeliveryDoc;
        var O = "C_OutboundDeliveryFs('" + deliverydoc + "')";
        var oCrossAppNav = sap.ushell.Container.getService("CrossApplicationNavigation");
        oCrossAppNav.toExternal({
          target: {
            shellHash: "OutboundDelivery-displayFactSheet&/" + encodeURIComponent(O)
          }
        });
      },
      // On click of Waybill, navigate to Fiori App based on the order type
      handleWaybillPress: function (oEvent) {
        var ordertype = oEvent.getSource().getParent().getBindingContext("Tab7Model").getObject().OrderType;
        var order = oEvent.getSource().getParent().getBindingContext("Tab7Model").getObject().PO;
        var deliverydoc = oEvent.getSource().getParent().getBindingContext("Tab7Model").getObject().DeliveryDoc;

        var oCrossAppNav = sap.ushell.Container.getService("CrossApplicationNavigation");
        if (ordertype == 'RT')  // Navigate to Display Customer Returns GUI app (VA03) for Return Order
        {
          oCrossAppNav.toExternal({
            target: { semanticObject: "CustomerReturn", action: "display" },
            params: { CustomerReturn: order }
          })
        }
        else { //Navigate to Manage Outbound Delivery Factsheet App (Standard) in case of Replacement, Repair and Vendor Return 
          var O = "C_OutboundDeliveryFs('" + deliverydoc + "')";
          oCrossAppNav.toExternal({
            target: {
              shellHash: "OutboundDelivery-displayFactSheet&/" + encodeURIComponent(O)
            }
          });
        }


      }
    });
  });
