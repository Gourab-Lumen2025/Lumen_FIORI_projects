sap.ui.define(
    [
        "sap/ui/core/mvc/Controller"
    ],
    function(BaseController) {
      "use strict";
  
      return BaseController.extend("lumen.zotcsparedashboard.controller.App", {
        onInit: function() {
        }
      });
    }
  );
  