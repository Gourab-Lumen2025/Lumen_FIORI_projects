## Application Details
|               |
| ------------- |
|**Generation Date and Time**<br>Mon Apr 14 2025 14:51:05 GMT+0000 (Coordinated Universal Time)|
|**App Generator**<br>@sap/generator-fiori-freestyle|
|**App Generator Version**<br>1.16.5|
|**Generation Platform**<br>SAP Business Application Studio|
|**Template Used**<br>simple|
|**Service Type**<br>SAP System (ABAP On Premise)|
|**Service URL**<br>http://ns2wd1app1.saperp.corp.intranet:44301/sap/opu/odata/sap/ZOTC_SPARES_DASHBOARD_PROJ_CDS|
|**Module Name**<br>zotcsparedashboard|
|**Application Title**<br>Replacement Screen|
|**Namespace**<br>lumen|
|**UI5 Theme**<br>sap_horizon|
|**UI5 Version**<br>1.108.31|
|**Enable Code Assist Libraries**<br>False|
|**Enable TypeScript**<br>False|
|**Add Eslint configuration**<br>False|

## zotcsparedashboard

Spare Dashoard

### Starting the generated app

-   This app has been generated using the SAP Fiori tools - App Generator, as part of the SAP Fiori tools suite.  In order to launch the generated app, simply run the following from the generated app root folder:

```
    npm start
```

- It is also possible to run the application using mock data that reflects the OData Service URL supplied during application generation.  In order to run the application with Mock Data, run the following from the generated app root folder:

```
    npm run start-mock
```

#### Pre-requisites:

1. Active NodeJS LTS (Long Term Support) version and associated supported NPM version.  (See https://nodejs.org)


