sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("com.lumen.zotcfldcomprpt.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);