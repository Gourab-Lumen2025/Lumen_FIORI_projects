sap.ui.define([
    "sap/m/MessageToast",
    "sap/m/Dialog",
    "sap/m/Label",
    "sap/m/Input",
    "sap/m/Button",
    "sap/m/ComboBox",
    "sap/ui/core/Item",
    "sap/ui/layout/form/SimpleForm",
    "sap/ui/core/BusyIndicator"
], function (MessageToast, Dialog, Label, Input, Button, ComboBox, Item, SimpleForm, BusyIndicator) {
    "use strict";

    return {

        /**
         * Custom Action - Update Division and Exception
         * Triggered from List Report custom toolbar button
         */
        fnUpdate: function (oContext, aSelectedContexts) {

            // --- Validate selection
            if (!aSelectedContexts || aSelectedContexts.length === 0) {
                MessageToast.show("Please select at least one record to update.");
                return;
            }




            const oModel = aSelectedContexts[0].getModel();  // same OData V4 model managed by FE
            const oData = aSelectedContexts[0].getObject();
            //Adding logic not to open up the popup
            if (!oData.AuthDivision){
                sap.m.MessageBox.error("You are not Authorized to Update the Record");
                return;
            }

            // --- ComboBox for Exceptions
            const oComboBox = new ComboBox({
                width: "100%",
                selectedKey: oData.fcrexception || "",
                placeholder: "Select Exception",
                 enabled: oData.AuthDivision == 'Y',
                showSecondaryValues: true
            });

            // Bind to service entity for exceptions
            oComboBox.bindItems({
                path: "/ZOTC_EXCEPTION_DESC",
                template: new Item({
                    key: "{Code}",
                    text: "{Description}"
                })
            });

            // --- Create the dialog
            const oDialog = new Dialog({
                title: "Update Division and Exception",
                contentWidth: "400px",
                content: new SimpleForm({
                    editable: true,
                    content: [
                        new Label({ text: "Division" }),
                        new Input({ value: oData.division, enabled: oData.AuthDivision == 'X' }),

                        new Label({ text: "Exception" }),
                        oComboBox
                    ]
                }),
                beginButton: new Button({
                    text: "Save",
                    type: "Emphasized",
                    enabled: oData.AuthDivision == 'X' || oData.AuthDivision == 'Y' ,
                    press: function () {
                        const aFormContent = oDialog.getContent()[0].getContent();
                        const sNewDivision = aFormContent[1].getValue();
                        const sNewException = oComboBox.getSelectedKey();

                        const oBindingContext = aSelectedContexts[0];
                        BusyIndicator.show(0);

                        // Update local model properties
                        oBindingContext.setProperty("division", sNewDivision);
                        oBindingContext.setProperty("fcrexception", sNewException);

                        // Use same group ID as framework
                        const sGroupId = oBindingContext.getBinding().getUpdateGroupId();


                        oModel.submitBatch(sGroupId)
                            .then(function () {
                                setTimeout(function () {
                                    const oParentBinding = oBindingContext.getBinding();

                                    if (oParentBinding && oParentBinding.refresh) {
                                        oParentBinding.refresh();
                                    } else {
                                        oModel.refresh();
                                    }

                                    sap.ui.core.BusyIndicator.hide();
                                }, 2000); // 1-second delay
                            })
                            .catch(function (oError) {
                                MessageToast.show("Error updating record.");
                                console.error(oError);
                            })
                            .finally(function () {
                                BusyIndicator.hide();
                                oDialog.close();
                            });

                    }
                }),
                endButton: new Button({
                    text: "Cancel",
                    press: function () {
                        oDialog.close();
                    }
                }),
                afterClose: function () {
                    oDialog.destroy();
                }
            });

            // Set same OData model to dialog (no token mismatch)
            oDialog.setModel(oModel);

            oDialog.open();
        }
    };
});
