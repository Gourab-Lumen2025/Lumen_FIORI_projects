sap.ui.define(['sap/fe/test/ObjectPage'], function(ObjectPage) {
    'use strict';

    var CustomPageDefinitions = {
        actions: {},
        assertions: {}
    };

    return new ObjectPage(
        {
            appId: 'com.lumen.zotcfldcomprpt',
            componentId: 'FCR_REPObjectPage',
            contextPath: '/FCR_REP'
        },
        CustomPageDefinitions
    );
});