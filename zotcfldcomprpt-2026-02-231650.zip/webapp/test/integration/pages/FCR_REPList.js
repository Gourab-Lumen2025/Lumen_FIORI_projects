sap.ui.define(['sap/fe/test/ListReport'], function(ListReport) {
    'use strict';

    var CustomPageDefinitions = {
        actions: {},
        assertions: {}
    };

    return new ListReport(
        {
            appId: 'com.lumen.zotcfldcomprpt',
            componentId: 'FCR_REPList',
            contextPath: '/FCR_REP'
        },
        CustomPageDefinitions
    );
});