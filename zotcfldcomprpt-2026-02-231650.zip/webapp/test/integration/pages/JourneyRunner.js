sap.ui.define([
    "sap/fe/test/JourneyRunner",
	"com/lumen/zotcfldcomprpt/test/integration/pages/FCR_REPList",
	"com/lumen/zotcfldcomprpt/test/integration/pages/FCR_REPObjectPage"
], function (JourneyRunner, FCR_REPList, FCR_REPObjectPage) {
    'use strict';

    var runner = new JourneyRunner({
        launchUrl: sap.ui.require.toUrl('com/lumen/zotcfldcomprpt') + '/test/flp.html#app-preview',
        pages: {
			onTheFCR_REPList: FCR_REPList,
			onTheFCR_REPObjectPage: FCR_REPObjectPage
        },
        async: true
    });

    return runner;
});

